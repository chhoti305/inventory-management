-- ============================================
-- Inventory Management System - MySQL Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;

-- Items table with indexed columns for query optimization
CREATE TABLE IF NOT EXISTS items (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    category    VARCHAR(50) NOT NULL,
    quantity    INT NOT NULL DEFAULT 0,
    price       DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    supplier    VARCHAR(100),
    created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_category (category),
    INDEX idx_quantity (quantity)
);

-- Transactions table for stock in/out tracking
CREATE TABLE IF NOT EXISTS transactions (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    item_id      INT NOT NULL,
    type         ENUM('IN', 'OUT') NOT NULL,
    quantity     INT NOT NULL,
    remarks      VARCHAR(255),
    created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (item_id) REFERENCES items(id) ON DELETE CASCADE,
    INDEX idx_item_id (item_id),
    INDEX idx_type (type)
);

-- Sample seed data
INSERT INTO items (name, category, quantity, price, supplier) VALUES
('Laptop',     'Electronics', 50,  45000.00, 'Dell India'),
('Monitor',    'Electronics',  5,  15000.00, 'LG'),
('Desk Chair', 'Furniture',    8,   7500.00, 'Featherlite'),
('Notebook',   'Stationery', 200,     45.00, 'Classmate'),
('Pen Box',    'Stationery',  15,     30.00, 'Reynolds');
